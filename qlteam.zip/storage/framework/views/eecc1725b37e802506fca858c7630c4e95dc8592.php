 
  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký sử dụng mail cho tài khoản SENDZ</title>
</head>
<body style="width: 650px;">
<h1>Đăng ký sử dụng mail cho tài khoản</h1> 
<p><em>Xin thông báo Bạn đã thực hiện đăng ký gmail của bạn làm địa chỉ hợp lệ cho tài khoản tại SENDZ.</em></p><br/><br/>
<p>Để đảm bảo an toàn trong khi sử dụng, đề nghị Bạn đọc kỹ các hướng dẫn, các điều khoản, điều kiện liên quan đến việc sử dụng dịch vụ được đăng tải trên website sendz.top </p>
<p>Đây là email tự động. Bạn vui lòng không gửi thư vào địa chỉ này. Mọi vướng mắc liên quan đến dịch vụ, Bạn liên hệ với Trung tâm dịch vụ khách hàng của SEN BANK theo số điện thoại 0838008448 hoặc mail cusenbonchen@gmail.com.</p><br/><br/>


<p style="font-size: 20px">Mời bạn vào link này để tiếp tục <a href="https://sendz.top/confirmmail?id=<?php echo e($mailData['id']); ?>&token=<?php echo e($mailData['body']); ?>">https://sendz.top/confirmmail?id=<?php echo e($mailData['id']); ?>&token=<?php echo e($mailData['body']); ?></a></p>

<p>Cám ơn Bạn đã sử dụng dịch vụ của Agribank!</p><br/>
</body> 
</html><?php /**PATH D:\Laravel\qlteam\resources\views/emails/RegisterMail.blade.php ENDPATH**/ ?>