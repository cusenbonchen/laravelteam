<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?dd($project);?>
<body>  
    <div class="wrapper">  
        <div class="row">
            <div class="col-md-12 d-flex justify-content-end">
            <div class="btn-group ">
              
            </div>
            </div>
        </row>
         
    </div>  
</body>
</html><?php /**PATH D:\Laravel\qlteam\resources\views/projectDetail.blade.php ENDPATH**/ ?>