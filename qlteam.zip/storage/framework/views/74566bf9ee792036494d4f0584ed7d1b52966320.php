<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label"><?php echo e(trans('auth.username')); ?></label>
  <input type="text" class="form-control" placeholder="<?php echo e(trans('auth.username_placeholder')); ?>">
</div>
<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label"><?php echo e(trans('auth.password')); ?></label>
  <input type="password" class="form-control" placeholder="<?php echo e(trans('auth.password_placeholder')); ?>">
</div>
<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\qlteam\resources\views/welcome.blade.php ENDPATH**/ ?>