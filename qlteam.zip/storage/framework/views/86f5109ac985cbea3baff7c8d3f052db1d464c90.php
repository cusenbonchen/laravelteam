<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<form action="<?php echo e(route('auth.confirmmail')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <div class="mb-3"> 
  <div class="col-auto">
      <button type="submit" class="btn btn-primary mb-3">Hoàn tất</button>
    </div>
   
</form>
</div>
<script>
  function getUrlParameter(name) {
      const urlParams = new URLSearchParams(window.location.search);
      return urlParams.get(name);
  }

  document.addEventListener("DOMContentLoaded", () => {
      const token = getUrlParameter('token');
      const id = getUrlParameter('id');
      if (token) {
          document.querySelector('input[name="token_email"]').value = token;
      }
      if (id) {
          document.querySelector('input[name="id"]').value = id;
      }
  });
</script>
<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\qlteam\resources\views/ConfirmMail.blade.php ENDPATH**/ ?>