<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('auth.login')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label"><?php echo e(trans('auth.username')); ?></label>
    <input type="text" name="username" class="form-control" placeholder="<?php echo e(trans('auth.username_placeholder')); ?>">
  </div>
  <div class="mb-3">
    <label class="form-label"><?php echo e(trans('auth.password')); ?></label>
    <input type="password" name="password" class="form-control" placeholder="<?php echo e(trans('auth.password_placeholder')); ?>">
  </div>
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3"><?php echo e(trans('auth.login_button')); ?></button>
  </div>
  <a href="<?php echo e(route('auth.forgot')); ?>"><?php echo e(trans('auth.forgot_password')); ?>?</a>
  <a href="<?php echo e(route('auth.register')); ?>"><?php echo e(trans('auth.register')); ?></a>
  <?php if(isset($message)): ?>
    <p><?php echo e($message); ?></p>
<?php endif; ?>
</form>
<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\qlteam\resources\views//login.blade.php ENDPATH**/ ?>