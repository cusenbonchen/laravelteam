
<div id="toast-container"></div>
<select name="setlang" id="setLang">
    <option value="vn">VN</option>
    <option value="en">EN</option> 
</select> 
</body>
</html><?php /**PATH D:\Laravel\qlteam\resources\views/common/footer.blade.php ENDPATH**/ ?>