<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<form action="<?php echo e(route('auth.forgotPass')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" autocomplete="off" require data-language="emailPlaceholder" placeholder="" required>
  </div> 
  <div class="col-auto">
      <button type="submit" class="btn btn-primary mb-3" data-language="sendButton"></button>
    </div>
    <?php if(isset($message)): ?>
      <p><?php echo e($message); ?></p>
  <?php endif; ?>
</form>
</div>
<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\qlteam\resources\views/forgotPassword.blade.php ENDPATH**/ ?>