<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<form action="<?php echo e(route('auth.register')); ?>" method="post">
<?php echo csrf_field(); ?>
    <div class="mb-3">
      <label class="form-label" data-language="username"> </label>
      <input type="text" name="username" class="form-control" autocomplete="off" data-language="usernamePlaceholder" placeholder="" required>
    </div>
    <div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" autocomplete="off" data-language="emailPlaceholder" placeholder="" required>
  </div> 
  <div class="mb-3">
      <label class="form-label" data-language="firstName"> </label>
      <input type="text" name="first_name" class="form-control" autocomplete="off" data-language="firstNamePlaceholder" placeholder="" required>
    </div>
    <div class="mb-3">
      <label class="form-label" data-language="lastName"> </label>
      <input type="text" name="last_name" class="form-control" autocomplete="off" data-language="lastNamePlaceholder" placeholder="" required>
    </div>
    <div class="mb-3">
      <label class="form-label" data-language="password"> </label>
      <input type="password" name="password" class="form-control" autocomplete="off" data-language="passwordPlaceholder" placeholder="" required>
    </div>
    <div class="mb-3">
      <label class="form-label" data-language="rePassword"></label>
      <input type="password" name="rePassword" class="form-control" autocomplete="off" data-language="passwordPlaceholder" placeholder="" required>
    </div>
    <div class="col-auto">
      <button type="submit" class="btn btn-primary mb-3" data-language="register"> </button>
    </div>  
    <?php if(isset($message)): ?>
      <p><?php echo e($message); ?></p>
  <?php endif; ?>
</form>
</div>
<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\qlteam\resources\views/Register.blade.php ENDPATH**/ ?>